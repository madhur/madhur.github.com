Interrupt Viewer
===============
Interrupt Viewer is a simple 1.30 KB program that lets you view the all the interrupt vector addresses of your PC. 
The program also stores all the addresses in a file vector.txt, so make sure that a file with same name doesnt exist in which you are executing the program.
This program has been written in x86 assembly for programmers wanting to ensure that their TSR's are vectored to correct addresses. T
he list of interrupt addresses is automatically saved in a text file for future references.

