Client Co-ordinates Revealer v1.0
=================================

Client Co-ordinates Revealer(CCR) is an excellent program for those who would like to quickly locate the co-ordinates of any window. it may be either child or parent window.
I made this program because i had difficulty in accurately placing the bitmaps,icons on my win32 programs.
The co-ordinates can be used in API functions like BitBlt,TranspareBlt...

Changes
=======
* no DLL used,faster!

* Some bug fixes for win2k/xp

Report any bugs to madhur_ahuja@yahoo.com

Madhur
India
