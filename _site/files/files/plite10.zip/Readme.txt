Password Revealer - By Madhur Ahuja
===================================
This simple program can display the passwords from the edit controls having ES_PASSWORD style. The program demonstrates the use of mouse hook.

Report any suggestions or improvements to madhur_ahuja@yahoo.com

Madhur Ahuja
India